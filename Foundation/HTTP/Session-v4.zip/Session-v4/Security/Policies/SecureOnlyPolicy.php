<?php

declare(strict_types=1);

namespace Avax\HTTP\Session\Security\Policies;

use RuntimeException;

/**
 * SecureOnlyPolicy - HTTPS-Only Session Policy
 *
 * Enforces that session operations only occur over HTTPS.
 * Prevents session hijacking over insecure connections.
 *
 * @package Avax\HTTP\Session\Policies
 */
final class SecureOnlyPolicy implements PolicyInterface
{
    /**
     * Enforce HTTPS-only policy.
     *
     * @param array<string, mixed> $data Current session data.
     *
     * @return void
     * @throws \RuntimeException If connection is not HTTPS.
     */
    public function enforce(array $data) : void
    {
        $isSecure = ! empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

        if (! $isSecure) {
            throw new RuntimeException(
                'Session access requires HTTPS connection for security.'
            );
        }
    }

    /**
     * Get policy name.
     *
     * @return string Policy identifier.
     */
    public function getName() : string
    {
        return 'secure_only';
    }
}
