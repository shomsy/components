<?php
declare(strict_types=1);

namespace Foundation\HTTP\Session\Locks;

use RuntimeException;

final class LockTimeoutException extends RuntimeException {}
